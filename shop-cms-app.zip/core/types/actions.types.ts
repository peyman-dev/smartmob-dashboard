export interface LoginPayloadType {
    username: string,
    password: string
}