export interface LoginPayloadType {
    username: string,
    password: string,
    code?: string | number
}