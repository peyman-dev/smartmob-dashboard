export const routes = [
    {
        id: crypto.randomUUID(),
        label: "خانه",
        path: "/"
    },
    {
        id: crypto.randomUUID(),
        label: "سفارشات",
        path: "/orders"
    },
    {
        id: crypto.randomUUID(),
        label: "کاربران",
        path: "/users"
    }
]