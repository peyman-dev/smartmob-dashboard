"use client"
import { Account } from "@/core/types/types";
import React from "react";

const ManageAccount = ({
  account,
  onSuccess,
}: {
  account: Account;
  onSuccess: () => {};
}) => {
  return <div>ManageAccount</div>;
};

export default ManageAccount;
