export const revalidate = 0;
import UsersTable from "@/components/templates/users/users-table";

const Page = () => {
  return (
    <main id="users-template">
      <UsersTable />
    </main>
  );
};

export default Page;
