import React from 'react'
import HomePage from './(home)/page'

const page = () => {
  return <HomePage/>
}

export default page