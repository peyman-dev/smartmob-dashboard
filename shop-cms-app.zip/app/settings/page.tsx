export const dynamic = "force-dynamic";
export const revalidate = 0;
import React from 'react'

const page = () => {
  return (
    <div>page</div>
  )
}

export default page