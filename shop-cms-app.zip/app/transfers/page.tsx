export const dynamic = "force-dynamic";
export const revalidate = 0;
import React from 'react'
import ClientPage from './client-page'

const page = () => {
  return <ClientPage />
}

export default page