import { locateImagePath } from "./helpers";

export const DEFAULT_AVATAR = locateImagePath("guest-user.png")