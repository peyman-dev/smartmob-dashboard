"use client";
import Currency from "@/components/common/currency";
import { User } from "@/core/types/types";
import { DollarSign } from "lucide-react";
import { useTranslations } from "next-intl";
import React from "react";

const UserBalance = ({ user }: { user: User }) => {
  const { money, currency } = user.accountInfo;
  const normalizedPrice = (price: number) => Math.floor(price);
  return (
    <div className="gap-1!">
      <span>
        {currency == "TOMAN"
          ? normalizedPrice(money.TOMAN)
          : normalizedPrice(money.USD)}
      </span>
      <Currency className="text-gray-500" currency={currency} />
    </div>
  );
};

export default UserBalance;
