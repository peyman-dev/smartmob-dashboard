import React from 'react'
export const dynamic = 'force-dynamic'; 
const page = () => {
  return (
    <div>Offline page {":>"}</div>
  )
}

export default page